#define BUILDNUMBER	movff 0,41
