#ifndef __DEBUGGER_H__
#define __DEBUGGER_H__

extern int debug_on_brk;
#endif